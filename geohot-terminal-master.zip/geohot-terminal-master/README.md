# geohot-terminal
Good morning.
This is the Terminal Geroge Hotz uses in his coding livestreams.This includes the Tmux, Vim and Bash theme. And while you are installing that you can listen to George's sick music => https://open.spotify.com/track/4V05j7HDUU2bZQwDOeIySh?si=vNkYCQTvSKO1xZyedjZJ1Q

Have Fun. 

# How to install: 

```
Copy the files to your HOME directory and you are good to go. 

#Now open Vim and type:

:so $MYVIMRC

#and then exit tmux if it's still running do:

tmux kill-server

#and then to finish it all:

sudo reboot
```

